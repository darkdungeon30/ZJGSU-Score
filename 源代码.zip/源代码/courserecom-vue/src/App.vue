<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>


export default {
  name: 'App',
}
</script>
<style scoped>
#app {
  color: #2c3e50;
}
</style>
